package cor;

public class SamlAuthenticationProvider implements AuthenticationProvider {

}
