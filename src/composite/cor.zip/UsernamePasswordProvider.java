package cor;

public class UsernamePasswordProvider implements AuthenticationProvider {

}
