package cor;

public class OAuthTokenProvider implements AuthenticationProvider {

}
