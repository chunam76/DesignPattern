package cor;

public interface AuthenticationProvider {

}
